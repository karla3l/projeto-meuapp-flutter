// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:meuapp/slideshow.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatelessWidget {
  const MeuApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.deepOrange,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.yellow,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text("Meu Aplicativo"),
        ),
        drawer: Menuzinho(),
        endDrawer: Menuzinho(),
        body: ListView(
          children: [
            Slideshow(),
            ListTile(
              leading: Perfil(),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 1");
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.home, size: 40),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 2");
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.settings, size: 40),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 3");
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.settings, size: 40),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 3");
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.settings, size: 40),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 3");
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.settings, size: 40),
              title: Text("Título do ListTile"),
              subtitle: Text("Subtítulo secundário"),
              trailing: Icon(Icons.chevron_right, size: 40),
              onTap: () {
                print("Clicou no ListTile 3");
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Menuzinho extends StatelessWidget {
  const Menuzinho({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          UserAccountsDrawerHeader(
            accountName: Text("Fulano de Souza"),
            accountEmail: Text("fulano@gmail.com"),
            currentAccountPicture: Perfil(),
          ),
          ListTile(
            leading: Icon(Icons.folder),
            title: Text("Meus Arquivos"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.people),
            title: Text("Compartilhado Comigo"),
            onTap: () {},
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.delete),
            title: Text("Lixeira"),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

class Botaozinho extends StatelessWidget {
  const Botaozinho({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      child: Text("CLIQUE AQUI"),
      onPressed: () {},
      style: ElevatedButton.styleFrom(),
    );
  }
}

class Perfil extends StatelessWidget {
  const Perfil({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String url = "https://randomuser.me/api/portraits/men/62.jpg";
    // return Image.network(url);
    return CircleAvatar(
      backgroundImage: NetworkImage(url),
    );
  }
}
